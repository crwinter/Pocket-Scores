package SportsFeedAPI;

import org.json.JSONObject;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class NumberOfGames {

    public static void main(String[] args) {
        // Create a HTTP Connection.
        String baseUrl = "https://rapidapi.p.rapidapi.com/games?league=NFL&date=2020-11-08";
        String callSport = "?league=NFL";
        String date = "&date=";
        String apiKey = "b5e4c2346emsh81375d22c74af66p13552ejsn6edf8a56cdad";
        String urlString = baseUrl + callSport + date;
        URL url;
        System.out.println("Marker 1");
        try {
            System.out.println("Marker 2");
            url = new URL(baseUrl);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("x-rapidapi-key","b5e4c2346emsh81375d22c74af66p13552ejsn6edf8a56cdad");
            con.setRequestProperty("x-rapidapi-host","sportspage-feeds.p.rapidapi.com");
            System.out.println("Marker 3");

            int status = con.getResponseCode();
            System.out.println("Response Code: " + status);
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer content = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            con.disconnect();
            System.out.println("Output: " + content.toString());
            JSONObject obj = new JSONObject(content.toString());
            int games = obj.getInt("games");
            System.out.println("Games: " + games);
        } catch (Exception ex) {
            Logger.getLogger(DemoAPI.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }

    }


}
